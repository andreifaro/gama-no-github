public class Avestruz extends Ave {

}

public void cuidadoclass() {
    System.out.println("Entrou no Hospital");
    System.out.println("Tratado com sucesso");
}