import java.awt.List;
import java.util.ArrayList;
import java.util.Scanner;
 
public class bancoteste {
 
    public static void main(final String[] args) {

        final Scanner leitor = new Scanner(System.in);
        int x = 500;
        int y = 100;
        String nome = "";
        contabancaria contaclass = new contabancaria(x, y, nome);
        System.out.println("\nBEM VINDO AO ITAU \n\n1-Criar Conta Corrente\n2-Transferencia\n3-Exibir Saldo\n4-Deposito\n5-Sair do programa\n");
        System.out.println("Digite seu Nome :");
               nome = leitor.nextLine();
               contaclass.setNome(nome);
               x++;
               y++;
               contaclass.setdados(x, y);
               System.out.println("\nConta Criada com Sucesso\n");
               System.out.println("Nome : " + contaclass.getNome());
               System.out.println("Agencia : " + contaclass.getAgencia());
               System.out.println("Conta : " + contaclass.getConta());
            System.out.println("Sua Agencia : " + contaclass.getAgencia()); 
            
    }
}