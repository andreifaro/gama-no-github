import java.util.ArrayList;
import java.util.List;

public class contabancaria {

    private static String nome;
    private String telefone;
    private static int conta;
    private Double saldo;
    static int agencia;

    public String getNome() {
        return nome;
    }

    public void setNome(String novoNome) {
        nome = novoNome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String novoTelefone) {
        telefone = novoTelefone;
    }

    public int getAgencia() {
        return agencia;
    }

    public int getConta() {
        return conta;
    }

    public void setdados(int x, int y) {
        agencia = x;
        conta = y;
    }
 
    public contabancaria(int x, int contaCadastrada, String nomeCadastrado) {
        agencia = x;
        conta = contaCadastrada;
        nome = nomeCadastrado;
        saldo = 0.0;
    }
 
    public void transferencia(String agencia, String conta, Double valor) {
 
    }
 
    public void transferencia(String telefone, Double valor) {
 
    }
 
    public void saque(Double valorSacado) {
        saldo -= valorSacado;
 
    }
 
    public void depositar(Double valorDepositado) {
        saldo += valorDepositado;
    }
 
    public Double exibirSaldo() {
        return saldo;
    } 
}