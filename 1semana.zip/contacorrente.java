public class contacorrente {
    public static void main(String[] args) {
         
        String[][] ccpessoa = { { "Joao","Bernardo","Luis" }, { "4", "5", "6" } };

         
        System.out.println("As contas são");
        saida( ccpessoa ); //exibe o array 2 por linha
             
    }
    
        private static void saida (String[][] ccpessoa) {
        }

        // FAZ UM LOOP PELAS LINHAS DO ARRAY
    public static void saida(int[][] ccpessoa)
    {
        //FAZ UM LOOP PELAS COLUNAS DA LINHA ATUAL
        for(int linha = 0; linha < ccpessoa.length; linha++)
        {
            //FAZ LOOP PELAS COLUNAS DA LINHA ATUAL
            for( int coluna = 0; coluna < ccpessoa[linha].length; coluna++)
                System.out.printf("%d ", ccpessoa[linha][coluna]);     
            System.out.println();
        }
    }
}