function validaCarrinho () {
  console.log("iniciando validação carrinho")
}
