public class ContaBancaria {

    private String nome;
    private Double saldo;
    private Integer conta;

    public boolean validaconta (int conta, Object listaContas) {
        for (int i=0, n=0; i < listaContas.size() && n!= 1; i++){
            ContaBancaria contaorigem = (ContaBancaria) ((Object) listaContas).get(conta -1);
                if(conta == ((ContaBancaria) (listaContas.get(i))).getConta())
                {   
                    System.out.println("Conta existe");
                    System.out.println("[Nome do Correntista]: " + contaorigem.getNome());
                    System.out.println("[Conta do Correntista]: " + contaorigem.getConta());
                    n++;
                    return true;
                } 
                else {
                    System.out.println("Conta nao existe");
                    return false;
            }
    } 
    }

    public void setNome(String novoNome) {
        nome = novoNome;
    }

    public String getNome() {
        return nome;
    }

    public Integer getConta() {
        return conta;
    }

    public void setSaldo(Double novoSaldo) {
    saldo = novoSaldo;
     }

    public Double getSaldo() {
    return saldo;
     }

    public ContaBancaria(String nomeCorrentista, Integer numeroConta) {
        nome = nomeCorrentista;
        saldo = 0.0;
        conta = numeroConta;
    }

    public Double exibirSaldo() {
        return saldo;
    }

    public void depositar(Double valorDepositado) {
        saldo += valorDepositado;
    }

    public void sacar(Double valorSacado) {
        saldo -= valorSacado;
    }

}