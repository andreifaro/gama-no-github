import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Programa {

    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);

        List listaContas = new ArrayList<ContaBancaria>();

        // ContaBancaria contaUm = new ContaBancaria("JC", novaConta());
        // ContaBancaria contaDois = new ContaBancaria("Andrei", novaConta());
        // ContaBancaria contaTres = new ContaBancaria("Beatriz", novaConta());
        // listaContas.add(contaUm);
        // listaContas.add(contaDois);
        // listaContas.add(contaTres);

        int opcaoSelecionada;
        do {

            System.out.println("Selecione uma opção: ");
            System.out.println("1 - Criar conta: ");
            System.out.println("2 - Listar todas as contas: ");
            System.out.println("3 - Transferencia: ");
            System.out.println("4 - Saldo: ");
            System.out.println("5 - Deposito: ");
            System.out.println("0 - Sair ");
            opcaoSelecionada = leitor.nextInt();

            int contaescolhida;
            switch (opcaoSelecionada) {
                // Criar Conta
                case 1:
                    String nome = leitor.next().trim();
                    ContaBancaria novaContaBancaria = new ContaBancaria(nome, novaConta());
                    listaContas.add(novaContaBancaria);
                    break;
                // Listar Todas as Contas
                case 2:
                    for (int contador = 0; contador < listaContas.size(); contador++) {

                        ContaBancaria contaTemporaria = (ContaBancaria) listaContas.get(contador);
                        System.out.println("[Nome do Correntista]: " + contaTemporaria.getNome());
                        System.out.println("[Saldo do Correntista]: " + contaTemporaria.exibirSaldo());
                        System.out.println("[Conta do Correntista]: " + contaTemporaria.getConta());
                        System.out.println("-------------------------------------------------------");
                    }
                    break;
                case 3:
                for (int contador = 0; contador < listaContas.size(); contador++) {

                    ContaBancaria contaTemporaria = (ContaBancaria) listaContas.get(contador);
                    System.out.println("[Nome do Correntista]: " + contaTemporaria.getNome());
                    System.out.println("[Conta do Correntista]: " + contaTemporaria.getConta());
                    System.out.println("-------------------------------------------------------");                   
                }
                    System.out.println("Escolha a conta desejada: ");
                    contaescolhida = leitor.nextInt();
                    for (int i=0, n=0; i < listaContas.size() && n!= 1; i++){
                    ContaBancaria contaorigem = (ContaBancaria) listaContas.get(contaescolhida -1);
                        if(contaescolhida == ((ContaBancaria) (listaContas.get(i))).getConta())
                        {   
                            System.out.println("Conta existe");
                            System.out.println("[Nome do Correntista]: " + contaorigem.getNome());
                            System.out.println("[Conta do Correntista]: " + contaorigem.getConta());
                            n++;
                        } 
                        else {
                            System.out.println("Conta nao existe");
                        }
                    }
                    break;
                case 0:
                    break;
                default:
                    System.out.println("Opção Invalida - Digite");
                    break;
            }
        } while (opcaoSelecionada != 0);

        leitor.close();

    }

    private static int listaContas(int i) {
        return 0;
    }

    public static int ids = 0;

    public static int novaConta() {
        return ids += 1;
    }

}