import java.util.Scanner;
 
public class impostoswitch {
 
    public static void main(String[] args) {
 
        Scanner leitor = new Scanner(System.in);
        System.out.println("\nDigite o nome do imposto a ser calculado \nICMS\nIPI\nISS\nIPQP");
        String impostoDigitado = leitor.nextLine();
        int n = 0;
        double valor;
        double resultado;
        do 
        {
        switch (impostoDigitado.toUpperCase()) {
            case "ICMS":
                System.out.print("Digite o Valor para aplicar o ICMS (10%): R$");
                valor = leitor.nextDouble();
                resultado = valor * 0.10;
                System.out.println("Valor a ser pago: R$" + resultado);
                n++;
                break;
            case "IPI":
                System.out.print("Digite o Valor para aplicar o IPI (20%): R$");
                valor = leitor.nextDouble();
                resultado = valor * 0.20;
                System.out.println("Valor a ser pago: R$" + resultado);
                n++;
                break;
            case "ISS":
                System.out.print("Digite o Valor para aplicar o ISS (50%) : R$");
                valor = leitor.nextDouble();
                resultado = valor * 0.50;
                System.out.println("Valor a ser pago: R$" + resultado);
                n++;
                break;
            case "IPQP":
                System.out.print("Digite o Valor para aplicar o IPQP (90%): R$");
                valor = leitor.nextDouble();
                resultado = valor * 0.90;
                System.out.println("Valor a ser pago: R$" + resultado);
                n++;
                break;
            default:
                System.out.println("Imposto invalido, digite novamente");
                impostoDigitado = leitor.nextLine();
                break;
            
            }} while (n <=0 );
        }
}