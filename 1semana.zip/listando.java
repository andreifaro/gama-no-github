import java.util.Scanner;
 
public class listando {
 
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
 
        System.out.println("Qual o tamanho total de registros?");
        int tamanhoLista = leitor.nextInt();
 
        // ARRAY
        String[] listaUsuarios = new String[tamanhoLista];
        int indiceDisponivel = 0;
 
        int opcaoDigitada;
        do {
 
            System.out.println("1 - Criar Usuario ");
            System.out.println("2 - Listar Usuarios");
            System.out.println("6 - Sair");
            opcaoDigitada = leitor.nextInt();
 
            switch (opcaoDigitada) {
                case 1:
                    if (indiceDisponivel < listaUsuarios.length) {
                        System.out.print("Digite o nome do usuario: ");
                        String nome = leitor.next();
                        listaUsuarios[indiceDisponivel] = nome;
                        indiceDisponivel += 1;
                    } else {
                        System.out.println("Lista Cheia");
                    }
                    break;
                case 2:
                    for (int indice = 0; indice < listaUsuarios.length; indice++) {
                        System.out.println("Nome do usuario: " + listaUsuarios[indice]);
                    }
                    break;
 
                default:
                    break;
            }
 
        } while (opcaoDigitada != 6);
 
    }
 
}