import java.util.Scanner;
public class media {
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        System.out.print("Digite sua nota1: ");
        int nota1 = leitor.nextInt();
        System.out.print("Digite sua nota2: ");
        int nota2 = leitor.nextInt();
        System.out.print("Digite sua nota3: ");
        int nota3 = leitor.nextInt();
        System.out.print("Digite sua nota4: ");
        int nota4 = leitor.nextInt();
            int soma = nota1 + nota2 + nota3 + nota4;
            System.out.println("Sua soma foi: " + soma);
                int media = soma/4;
                System.out.println("Sua media foi: " + media);
        
                    if( media >= 7.5){
                         System.out.println("Aluno Aprovado");
                }  else{
                        System.out.println("Aluno Reprovado - Estudar mais");
            }
        leitor.close();
    }
}