import java.util.Scanner;
public class medianova {
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        double soma = 0;
        int ind = 1;
        int n = 1;
        System.out.print("Digite Quantidade de notas a serem digitadas :");
        int qtd = leitor.nextInt();
        do 
            {
                    System.out.print("Digite sua nota" +n + ": ");
                    double nota1 = leitor.nextDouble();
                    if (nota1 >= 11 ){;
                        System.out.println("Digitar Nota de 0 a 10");
                        ind--;
                        n--;
                        soma = soma - nota1; 
                    }
                soma = nota1 + soma;
                ind++;
                n++;
            } while (ind <=qtd);
                System.out.println("Sua soma foi: " + soma);
                double media = soma/qtd;
                System.out.println("Sua media foi: " + media);
        
                    if( media >= 7.5){
                         System.out.println("Aluno Aprovado");
                }  else{
                        System.out.println("Aluno Reprovado - Estudar mais");
            }
        leitor.close();
    }
}