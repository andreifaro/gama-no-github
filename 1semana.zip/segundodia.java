import java.util.Scanner;
public class segundodia {
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        System.out.print("Digite sua idade: ");
        int idade = leitor.nextInt();
        if(idade >= 60){
            System.out.println("Redobre a atencao e nao saia de casa");
        }  else{
            System.out.println("Digite 0 senao tiver doenças respiratorias e 1 para doenças : ");
            int doenca = leitor.nextInt();
                if (doenca == 1)
                System.out.println("Redobre a atencao e nao saia de casa");
                }
            System.out.println("Use mascara para sair de casa");
            }
    }
