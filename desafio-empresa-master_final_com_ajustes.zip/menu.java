public class menu {

    public void menuprincipal() {

    System.out.println("----BEM VINDO----");
    System.out.println("1- Criar Empresa");
    System.out.println("2- Criar Pessoa");
    System.out.println("3- Contratar Pessoa");
    System.out.println("4- Convidar a sair");
    System.out.println("5- Sair do programa");
    }
}